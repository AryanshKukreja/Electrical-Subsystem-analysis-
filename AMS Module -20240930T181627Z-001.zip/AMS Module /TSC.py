import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


df = pd.read_csv('AMSCelldata97.csv')

num_rows = len(df)
time_values = np.arange(0, num_rows * 0.1, 0.1)  # Assuming 100ms interval


plt.figure(figsize=(10, 6))
plt.plot(time_values, df['TSC'], color='blue', marker='o', linestyle='-')
plt.title('TSC vs Time')
plt.xlabel('Time (s)')
plt.ylabel('TSC')
plt.grid(True)
plt.show()
