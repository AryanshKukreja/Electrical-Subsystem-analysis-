
import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Read the CSV file and extract data from the first 96 columns
df = pd.read_csv('AMSCelldata97.csv')
data = df.iloc[:, :96]  # Extracting data from the first 96 columns


column__averages = data.mean(axis=0)

# Step 3: Plot the averages as 96 bars
plt.figure(figsize=(12, 6))
for i, avg in enumerate(column__averages):
    plt.bar(i + 1, avg, color='skyblue')

plt.title('Average Data in Each Column')
plt.xlabel('Cell Number')
plt.ylabel('Average Value')
plt.grid(True)
plt.show()
