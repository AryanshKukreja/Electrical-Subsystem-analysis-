import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Step 1: Read the CSV file
df = pd.read_csv('AMSCelldata97.csv')

# Step 2: Generate timestamp values
num_rows = len(df)
time_values = np.arange(0, num_rows * 0.1, 0.1)  # Assuming 100ms interval

# Step 3: Plot TSC vs time
plt.figure(figsize=(10, 6))
plt.plot(time_values, df['TSV'], color='blue', marker='o', linestyle='-')
plt.title('TSV vs Time')
plt.xlabel('Time (s)')
plt.ylabel('TSV')
plt.grid(True)
plt.show()
