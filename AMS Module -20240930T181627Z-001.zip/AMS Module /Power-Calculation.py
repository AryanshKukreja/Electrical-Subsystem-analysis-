import pandas as pd


df = pd.read_csv('AMSCelldata97.csv')


df['Power'] = df['TSC'] * df['TSV']

average_power = df['Power'].mean()

modulus_avg_power = abs(average_power)

print(f'The modulus of the average power is: {modulus_avg_power} w')
